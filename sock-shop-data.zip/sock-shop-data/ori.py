import pandas as pd

file_path = 'carts-cpu/1/normal.csv'

data = pd.read_csv(file_path)

from orion.data import load_signal

train_data = load_signal('carts-cpu/1/normal.csv')
train_data.head()

from orion import Orion

hyperparameters = {
    'orion.primitives.aer.AER#1': {
        'epochs': 5,
        'verbose': True
    }
}

orion = Orion(
    pipeline='aer',
    hyperparameters=hyperparameters
)

orion.fit(train_data)

new_data = load_signal('carts-cpu/1/anomalous.csv')
anomalies = orion.detect(new_data)